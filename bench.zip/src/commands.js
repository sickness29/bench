'use strict';

/**
 * Requires
 */
const __ = require('src/words');
const helper = require('./helper');


/**
 * Commands
 */
module.exports = {

  /**
   * Bench command
   *
   * @param {object} commandArguments Command Arguments
   *
   * @return {object} Request promise
   */
  b: function (commandArguments) {
    return Promise.resolve(helper.formatMessage('Бенч', 'путін' + __.randomize() + 'бенч'));
  },

  /**
   *
   *
   * @param {object} commandArguments Command Arguments
   *
   * @return {object} Request promise
   */
  pb(commandArguments) {
    return Promise.resolve(helper.formatMessage('ПроєБенч', 'путін' + __.randomize() + 'проєбенч'));
  }
};
