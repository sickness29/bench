'use strict';

/**
 * Token
 */
module.exports = '5721942834:AAFC-MYZzOHtf9pm_WA96m3XYUkQJZMQM-E';
