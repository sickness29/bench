'use strict';

/**
 * Token
 */
module.exports = 'Your Telegram token here';
